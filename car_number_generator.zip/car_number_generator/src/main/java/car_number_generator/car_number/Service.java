package car_number_generator.car_number;


public interface Service {
    Integer getAlike(String number);
    void addCarNumber(CarNumber carNumber);
}
