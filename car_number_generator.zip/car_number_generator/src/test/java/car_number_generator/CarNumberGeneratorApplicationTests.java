package car_number_generator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarNumberGeneratorApplicationTests {

    @Test
    void contextLoads() {
    }

}
